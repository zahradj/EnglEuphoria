import React from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AudioButton } from "@/components/AudioButton";
import { Clock, Users, Target, Star, Book, Volume2, Gamepad2, Zap } from "lucide-react";

export const Lesson54Intro = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-fun p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <Badge variant="secondary" className="mb-4">
            Pre-Starter • Unit 5 • Lesson 4
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">
            🐾 Animal Actions!
          </h1>
          <p className="text-xl text-muted-foreground">
            Learn what animals can do: swim, fly, run, jump!
          </p>
        </div>

        {/* Actions Preview Cards */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-4xl mb-2">🏊‍♀️</div>
              <h3 className="font-bold">Swim</h3>
              <p className="text-sm text-muted-foreground">Fish can swim</p>
            </CardContent>
          </Card>
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-4xl mb-2">🦅</div>
              <h3 className="font-bold">Fly</h3>
              <p className="text-sm text-muted-foreground">Birds can fly</p>
            </CardContent>
          </Card>
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-4xl mb-2">🏃‍♂️</div>
              <h3 className="font-bold">Run</h3>
              <p className="text-sm text-muted-foreground">Dogs can run</p>
            </CardContent>
          </Card>
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-4xl mb-2">🦘</div>
              <h3 className="font-bold">Jump</h3>
              <p className="text-sm text-muted-foreground">Monkeys can jump</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {/* What We'll Learn Today */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5 text-primary" />
                What We'll Learn Today
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Animal actions: swim, fly, run, jump</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Sentences: "Animals can..." patterns</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Matching animals to their actions</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Phonics: Letter Ll /l/ (lion, leaf, love)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Review: All animals from Unit 5</span>
              </div>
            </CardContent>
          </Card>

          {/* Action Activities */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Gamepad2 className="w-5 h-5 text-success" />
                Action Activities
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Animal action charades</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Swimming, flying practice</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Action matching games</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>"Can" sentence building</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Animal ability quiz</span>
              </div>
            </CardContent>
          </Card>

          {/* Lesson Information */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-lesson-orange" />
                Lesson Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Duration:</span>
                <span className="font-medium">25–30 minutes</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Slides:</span>
                <span className="font-medium">21 interactive slides</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Class Size:</span>
                <span className="font-medium">One-on-one</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Focus:</span>
                <span className="font-medium">Animal abilities</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Reward:</span>
                <span className="font-medium">🏅 Animal Expert Badge</span>
              </div>
            </CardContent>
          </Card>

          {/* Key Vocabulary */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Book className="w-5 h-5 text-lesson-purple" />
                Key Vocabulary & Sentences
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Action Words:</h4>
                <div className="grid grid-cols-2 gap-2">
                  <div className="flex items-center justify-between">
                    <span>🏊‍♀️ Swim</span>
                    <AudioButton text="swim" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>🦅 Fly</span>
                    <AudioButton text="fly" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>🏃‍♂️ Run</span>
                    <AudioButton text="run" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>🦘 Jump</span>
                    <AudioButton text="jump" />
                  </div>
                </div>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Key Sentences:</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">"Fish can swim."</span>
                    <AudioButton text="Fish can swim" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">"Birds can fly."</span>
                    <AudioButton text="Birds can fly" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Teaching Notes */}
        <Card className="bg-gradient-card border-0 shadow-card mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="w-5 h-5 text-warning" />
              One-on-One Teaching Notes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm">
              <p>
                <strong>Physical Actions:</strong> Encourage students to act out swimming, flying, running, and jumping motions while saying the words.
              </p>
              <p>
                <strong>Can Structure:</strong> Focus on the modal verb "can" - "Fish can swim" vs "I can swim." This introduces ability concepts.
              </p>
              <p>
                <strong>Animal Logic:</strong> Help students understand why certain animals do certain actions based on their body parts and habitats.
              </p>
              <p>
                <strong>Interactive Practice:</strong> Use charades and action games to make the lesson engaging and memorable.
              </p>
              <p>
                <strong>Homework Suggestion:</strong> Draw animals doing their special actions and write "X can Y" sentences.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            variant="outline" 
            size="lg"
            onClick={() => navigate("/")}
            className="flex items-center gap-2"
          >
            ← Back to Home
          </Button>
          <Button 
            size="lg" 
            onClick={() => navigate("/lesson54")}
            className="flex items-center gap-2 bg-gradient-primary hover:bg-gradient-primary/90"
          >
            <Zap className="w-5 h-5" />
            Learn Animal Actions!
          </Button>
        </div>
      </div>
    </div>
  );
};