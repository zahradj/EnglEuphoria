import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { FloatingLogo } from "@/components/FloatingLogo";
import { ProgressBar } from "@/components/ProgressBar";
import { AudioButton } from "@/components/AudioButton";
import { DragDropActivity } from "@/components/DragDropActivity";
import { PhonicsActivity } from "@/components/PhonicsActivity";
import { SpeakingActivity } from "@/components/SpeakingActivity";
import { BadgeReward } from "@/components/BadgeReward";

const totalSlides = 18;

export default function Lesson71() {
  const [currentSlide, setCurrentSlide] = useState(1);
  const navigate = useNavigate();

  const nextSlide = () => {
    if (currentSlide < totalSlides) {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const renderSlide = () => {
    switch (currentSlide) {
      case 1:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-4xl font-bold text-white mb-4">🍎🍌 Food Fun: Fruits</h2>
            <p className="text-xl text-white/90">Let's learn about delicious fruits!</p>
            <div className="text-6xl">🍎🍌🍇</div>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Let's Start! →
            </Button>
          </div>
        );

      case 2:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">📚 Quick Review</h2>
            <p className="text-lg text-white/90">Let's review family from Unit 6!</p>
            <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
              <AudioButton text="Mother" className="bg-white/20 hover:bg-white/30 text-white text-sm" />
              <AudioButton text="Father" className="bg-white/20 hover:bg-white/30 text-white text-sm" />
              <AudioButton text="Brother" className="bg-white/20 hover:bg-white/30 text-white text-sm" />
              <AudioButton text="Sister" className="bg-white/20 hover:bg-white/30 text-white text-sm" />
            </div>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Continue →
            </Button>
          </div>
        );

      case 3:
        return (
          <PhonicsActivity
            letter="N"
            words={[
              { word: "nose", image: "nose", hasLetter: true },
              { word: "net", image: "net", hasLetter: true },
              { word: "cat", image: "cat", hasLetter: false }
            ]}
            onComplete={nextSlide}
          />
        );

      case 4:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🍎 Apple</h2>
            <div className="text-8xl mb-4">🍎</div>
            <AudioButton text="Apple" className="bg-white/20 hover:bg-white/30 text-white text-xl px-8 py-4" />
            <p className="text-lg text-white/90">Red, sweet, and crunchy!</p>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Next →
            </Button>
          </div>
        );

      case 5:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🍌 Banana</h2>
            <div className="text-8xl mb-4">🍌</div>
            <AudioButton text="Banana" className="bg-white/20 hover:bg-white/30 text-white text-xl px-8 py-4" />
            <p className="text-lg text-white/90">Yellow, soft, and sweet!</p>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Next →
            </Button>
          </div>
        );

      case 6:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🔊 Listen & Repeat</h2>
            <div className="space-y-4">
              <div className="flex justify-center gap-4">
                <AudioButton text="Apple" className="bg-white/20 hover:bg-white/30 text-white" />
                <AudioButton text="Banana" className="bg-white/20 hover:bg-white/30 text-white" />
              </div>
              <p className="text-lg text-white/90">Click and repeat each word!</p>
            </div>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Continue →
            </Button>
          </div>
        );

      case 7:
        return (
          <DragDropActivity
            title="Match Fruits"
            items={[
              { id: '1', content: 'Apple', type: 'source', matchId: '3' },
              { id: '2', content: 'Banana', type: 'source', matchId: '4' },
              { id: '3', content: '🍎', type: 'target' },
              { id: '4', content: '🍌', type: 'target' }
            ]}
            onComplete={nextSlide}
          />
        );

      case 8:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">📝 Grammar: I like...</h2>
            <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20 max-w-md mx-auto">
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🍎</span>
                  <span className="text-white text-lg">"I like apples."</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🍌</span>
                  <span className="text-white text-lg">"I like bananas."</span>
                </div>
              </div>
            </Card>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Practice →
            </Button>
          </div>
        );

      case 9:
        return (
          <SpeakingActivity
            prompt="Look at the fruit and say: 'I like apples'"
            expectedResponse="I like apples"
            onComplete={nextSlide}
          />
        );

      case 10:
        return (
          <SpeakingActivity
            prompt="Look at the fruit and say: 'I like bananas'"
            expectedResponse="I like bananas"
            onComplete={nextSlide}
          />
        );

      case 11:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🛒 Fruit Shopping Game</h2>
            <p className="text-lg text-white/90">What do you want to buy?</p>
            <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
              <Button onClick={nextSlide} className="bg-green-500 hover:bg-green-600 text-white p-4">
                <div className="text-3xl mb-1">🍎</div>
                <div className="text-sm">Apple</div>
              </Button>
              <Button className="bg-white/20 hover:bg-white/30 text-white p-4">
                <div className="text-3xl mb-1">🚗</div>
                <div className="text-sm">Car</div>
              </Button>
              <Button className="bg-white/20 hover:bg-white/30 text-white p-4">
                <div className="text-3xl mb-1">📚</div>
                <div className="text-sm">Book</div>
              </Button>
            </div>
            <p className="text-white/80">Choose the fruit!</p>
          </div>
        );

      case 12:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🎮 Fruit Quiz</h2>
            <p className="text-lg text-white/90">Which fruit is yellow?</p>
            <div className="space-y-2">
              <Button className="bg-white/20 hover:bg-white/30 text-white block mx-auto">
                🍎 Apple
              </Button>
              <Button onClick={nextSlide} className="bg-green-500 hover:bg-green-600 text-white block mx-auto">
                🍌 Banana ✓
              </Button>
            </div>
          </div>
        );

      case 13:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🎭 Fruit Taste Test</h2>
            <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20 max-w-md mx-auto">
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">👧</span>
                  <span className="text-white">"I like apples! They are sweet!"</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">👦</span>
                  <span className="text-white">"I like bananas! They are soft!"</span>
                </div>
              </div>
            </Card>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Continue →
            </Button>
          </div>
        );

      case 14:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🎭 Role-Play</h2>
            <p className="text-lg text-white/90">Tell me about your favorite fruit!</p>
            <div className="space-y-4">
              <div className="text-6xl">🍎🍌</div>
              <p className="text-white/80">Say: "I like..." and choose apple or banana</p>
            </div>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Great Choice! →
            </Button>
          </div>
        );

      case 15:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">📝 Quick Review</h2>
            <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="text-4xl mb-2">🍎</div>
                <p className="text-white">Apple</p>
              </Card>
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
                <div className="text-4xl mb-2">🍌</div>
                <p className="text-white">Banana</p>
              </Card>
            </div>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Continue →
            </Button>
          </div>
        );

      case 16:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🏠 Homework</h2>
            <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20 max-w-md mx-auto">
              <div className="space-y-4 text-white">
                <p className="font-semibold">For next time:</p>
                <ul className="text-left space-y-2">
                  <li>• Draw an apple and a banana</li>
                  <li>• Practice saying: "I like apples"</li>
                  <li>• Practice saying: "I like bananas"</li>
                  <li>• Ask family about their favorite fruit</li>
                </ul>
              </div>
            </Card>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Finish Lesson →
            </Button>
          </div>
        );

      case 17:
        return (
          <div className="text-center space-y-6">
            <h2 className="text-3xl font-bold text-white mb-4">🌟 Lesson Complete!</h2>
            <div className="text-6xl mb-4">🎉</div>
            <p className="text-xl text-white/90">You learned about fruits!</p>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 max-w-md mx-auto">
              <p className="text-white font-semibold">New Words: Apple, Banana</p>
              <p className="text-white/80">Grammar: "I like..."</p>
            </div>
            <Button onClick={nextSlide} className="bg-white/20 hover:bg-white/30 text-white">
              Get Badge! →
            </Button>
          </div>
        );

      case 18:
        return (
          <BadgeReward
            title="Congratulations!"
            description="You completed Lesson 7.1!"
            badgeName="Fruit Lover Badge"
            onContinue={() => navigate('/lesson/7-2-intro')}
          />
        );

      default:
        return <div>Slide not found</div>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-warm relative overflow-hidden">
      <FloatingLogo />
      
      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-4xl mx-auto">
          <ProgressBar current={currentSlide} total={totalSlides} />
          
          <Card className="p-8 bg-white/10 backdrop-blur-sm border-white/20 min-h-[500px] flex items-center justify-center">
            {renderSlide()}
          </Card>
          
          <div className="mt-6 flex justify-between">
            <Button 
              onClick={() => navigate('/lesson/7-1-intro')}
              variant="outline"
              className="text-white border-white/30 hover:bg-white/10"
            >
              ← Back to Intro
            </Button>
            
            <div className="text-white/60">
              Slide {currentSlide} of {totalSlides}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}