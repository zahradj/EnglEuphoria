import React from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AudioButton } from "@/components/AudioButton";
import { Clock, Users, Target, Star, Book, Volume2, Gamepad2, Zap, Trophy } from "lucide-react";

export const Lesson43Intro = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-fun p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <Badge variant="secondary" className="mb-4">
            Pre-Starter • Unit 4 • Lesson 3
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">
            🧍 My Body Review!
          </h1>
          <p className="text-xl text-muted-foreground">
            Let's review everything we learned about our body!
          </p>
        </div>

        {/* Body Parts Review Cards */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-3xl mb-2">🧠 👀 👃</div>
              <h3 className="font-bold">Lesson 4.1</h3>
              <p className="text-sm text-muted-foreground">Head, Eyes, Nose</p>
            </CardContent>
          </Card>
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-3xl mb-2">👄 👋 🦶</div>
              <h3 className="font-bold">Lesson 4.2</h3>
              <p className="text-sm text-muted-foreground">Mouth, Hands, Feet</p>
            </CardContent>
          </Card>
          <Card className="text-center border-2 border-success/20 hover:border-success/40 transition-colors bg-gradient-success/10">
            <CardContent className="pt-6">
              <div className="text-3xl mb-2">🏆</div>
              <h3 className="font-bold text-success">Review All!</h3>
              <p className="text-sm text-muted-foreground">Complete Body</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {/* What We'll Review Today */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-warning" />
                What We'll Review Today
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-warning rounded-full"></div>
                <span>All body parts: head, eyes, nose, mouth, hands, feet</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-warning rounded-full"></div>
                <span>Phonics review: Letters Aa–Hh with sounds</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-warning rounded-full"></div>
                <span>Sentences: "This is my..." / "These are my..."</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-warning rounded-full"></div>
                <span>Complete body puzzle challenge</span>
              </div>
            </CardContent>
          </Card>

          {/* Fun Review Activities */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Gamepad2 className="w-5 h-5 text-success" />
                Fun Review Activities
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Simon Says Challenge Game</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Spin & Speak Magic Wheel</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Body Puzzle Race</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Mini Comic Role-Play</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Interactive review quiz</span>
              </div>
            </CardContent>
          </Card>

          {/* Lesson Information */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-lesson-orange" />
                Lesson Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Duration:</span>
                <span className="font-medium">25–30 minutes</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Slides:</span>
                <span className="font-medium">20 interactive slides</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Class Size:</span>
                <span className="font-medium">One-on-one</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Focus:</span>
                <span className="font-medium">Full body review</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Reward:</span>
                <span className="font-medium">🏅 Body Champion Badge</span>
              </div>
            </CardContent>
          </Card>

          {/* Complete Vocabulary */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Book className="w-5 h-5 text-lesson-purple" />
                Complete Body Vocabulary
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">All Body Parts:</h4>
                <div className="grid grid-cols-2 gap-2">
                  <div className="flex items-center justify-between">
                    <span>🧠 Head</span>
                    <AudioButton text="head" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>👀 Eyes</span>
                    <AudioButton text="eyes" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>👃 Nose</span>
                    <AudioButton text="nose" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>👄 Mouth</span>
                    <AudioButton text="mouth" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>👋 Hands</span>
                    <AudioButton text="hands" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>🦶 Feet</span>
                    <AudioButton text="feet" />
                  </div>
                </div>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Phonics Review:</h4>
                <div className="flex justify-center">
                  <AudioButton text="A, B, C, D, E, F, G, H" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Teaching Notes */}
        <Card className="bg-gradient-card border-0 shadow-card mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="w-5 h-5 text-warning" />
              One-on-One Teaching Notes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm">
              <p>
                <strong>Physical Practice:</strong> Encourage the student to point to their own body parts on camera during the lesson for real-time practice.
              </p>
              <p>
                <strong>Grammar Focus:</strong> Alternate between singular "This is my head" and plural "These are my hands" to reinforce correct usage.
              </p>
              <p>
                <strong>Interactive Leadership:</strong> You lead Simon Says and role-play activities to keep the student engaged and active.
              </p>
              <p>
                <strong>Comprehensive Review:</strong> This lesson consolidates all Unit 4 learning before moving to new content.
              </p>
              <p>
                <strong>Homework Suggestion:</strong> Have the student draw a complete picture of themselves and label all 6 body parts in English.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            variant="outline" 
            size="lg"
            onClick={() => navigate("/")}
            className="flex items-center gap-2"
          >
            ← Back to Home
          </Button>
          <Button 
            size="lg" 
            onClick={() => navigate("/lesson43")}
            className="flex items-center gap-2 bg-gradient-primary hover:bg-gradient-primary/90"
          >
            <Zap className="w-5 h-5" />
            Start Body Review!
          </Button>
        </div>
      </div>
    </div>
  );
};