import React from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AudioButton } from "@/components/AudioButton";
import { Clock, Users, Target, Star, Book, Volume2, Gamepad2, Zap } from "lucide-react";

export const Lesson53Intro = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-fun p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <Badge variant="secondary" className="mb-4">
            Pre-Starter • Unit 5 • Lesson 3
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">
            🦁 Wild Animals!
          </h1>
          <p className="text-xl text-muted-foreground">
            Explore the wild and meet lion, elephant, and monkey!
          </p>
        </div>

        {/* Wild Animals Preview Cards */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-4xl mb-2">🦁</div>
              <h3 className="font-bold">Lion</h3>
              <p className="text-sm text-muted-foreground">It is a lion</p>
              <p className="text-xs text-muted-foreground">Roar! 🔊</p>
            </CardContent>
          </Card>
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-4xl mb-2">🐘</div>
              <h3 className="font-bold">Elephant</h3>
              <p className="text-sm text-muted-foreground">It is an elephant</p>
              <p className="text-xs text-muted-foreground">Trumpet! 🔊</p>
            </CardContent>
          </Card>
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-4xl mb-2">🐵</div>
              <h3 className="font-bold">Monkey</h3>
              <p className="text-sm text-muted-foreground">It is a monkey</p>
              <p className="text-xs text-muted-foreground">Ooh ooh! 🔊</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {/* What We'll Learn Today */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5 text-primary" />
                What We'll Learn Today
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Wild animals: lion, elephant, monkey</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Animal sounds: roar, trumpet, ooh-ooh</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Sentences: "It is a/an..." patterns</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Phonics: Letter Kk /k/ (king, kite, key)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Review: Pets and farm animals</span>
              </div>
            </CardContent>
          </Card>

          {/* Safari Adventures */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Gamepad2 className="w-5 h-5 text-success" />
                Safari Adventures
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Wild animal sound safari</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Jungle hide and seek</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Animal size comparison</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Safari binoculars game</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Wild animal matching</span>
              </div>
            </CardContent>
          </Card>

          {/* Lesson Information */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-lesson-orange" />
                Lesson Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Duration:</span>
                <span className="font-medium">25–30 minutes</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Slides:</span>
                <span className="font-medium">20 interactive slides</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Class Size:</span>
                <span className="font-medium">One-on-one</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Theme:</span>
                <span className="font-medium">Wild animals safari</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Reward:</span>
                <span className="font-medium">🏅 Safari Explorer Badge</span>
              </div>
            </CardContent>
          </Card>

          {/* Key Vocabulary */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Book className="w-5 h-5 text-lesson-purple" />
                Key Vocabulary & Sentences
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Wild Animals:</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span>🦁 Lion (roar)</span>
                    <AudioButton text="lion" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>🐘 Elephant (trumpet)</span>
                    <AudioButton text="elephant" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>🐵 Monkey (ooh-ooh)</span>
                    <AudioButton text="monkey" />
                  </div>
                </div>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Key Sentences:</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">"It is a lion."</span>
                    <AudioButton text="It is a lion" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">"It is an elephant."</span>
                    <AudioButton text="It is an elephant" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">"It is a monkey."</span>
                    <AudioButton text="It is a monkey" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Teaching Notes */}
        <Card className="bg-gradient-card border-0 shadow-card mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="w-5 h-5 text-warning" />
              One-on-One Teaching Notes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm">
              <p>
                <strong>Safari Adventure:</strong> Create excitement about exploring the wild. Use dramatic animal sounds and gestures to bring the safari experience to life.
              </p>
              <p>
                <strong>Article Practice:</strong> Focus on "a" vs "an" - "a lion," "a monkey" but "an elephant." This is important grammar foundation.
              </p>
              <p>
                <strong>Size Concepts:</strong> Introduce big/small concepts naturally - "The elephant is big!" "The monkey is small!"
              </p>
              <p>
                <strong>Wild vs Domestic:</strong> Help students understand these animals live in the wild, unlike pets and farm animals.
              </p>
              <p>
                <strong>Homework Suggestion:</strong> Draw a jungle scene with lion, elephant, and monkey. Label each animal.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            variant="outline" 
            size="lg"
            onClick={() => navigate("/")}
            className="flex items-center gap-2"
          >
            ← Back to Home
          </Button>
          <Button 
            size="lg" 
            onClick={() => navigate("/lesson53")}
            className="flex items-center gap-2 bg-gradient-primary hover:bg-gradient-primary/90"
          >
            <Zap className="w-5 h-5" />
            Start Safari Adventure!
          </Button>
        </div>
      </div>
    </div>
  );
};