import React from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AudioButton } from "@/components/AudioButton";
import { Clock, Users, Target, Star, Book, Volume2, Gamepad2, Zap } from "lucide-react";

export const Lesson51Intro = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-fun p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <Badge variant="secondary" className="mb-4">
            Pre-Starter • Unit 5 • Lesson 1
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">
            🐾 Pets!
          </h1>
          <p className="text-xl text-muted-foreground">
            Meet our furry and fishy friends: cat, dog, and fish
          </p>
        </div>

        {/* Pet Preview Cards */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-4xl mb-2">🐱</div>
              <h3 className="font-bold">Cat</h3>
              <p className="text-sm text-muted-foreground">It is a cat</p>
              <p className="text-xs text-muted-foreground">Meow! 🔊</p>
            </CardContent>
          </Card>
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-4xl mb-2">🐶</div>
              <h3 className="font-bold">Dog</h3>
              <p className="text-sm text-muted-foreground">It is a dog</p>
              <p className="text-xs text-muted-foreground">Woof! 🔊</p>
            </CardContent>
          </Card>
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-4xl mb-2">🐟</div>
              <h3 className="font-bold">Fish</h3>
              <p className="text-sm text-muted-foreground">It is a fish</p>
              <p className="text-xs text-muted-foreground">Bubble! 🔊</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {/* What We'll Learn Today */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5 text-primary" />
                What We'll Learn Today
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Pet animals: cat, dog, fish</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Animal sounds: meow, woof, bubble</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Sentences: "It is a cat/dog/fish"</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Phonics: Letter Ii /ɪ/ (insect, igloo)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Review: Body parts from Unit 4</span>
              </div>
            </CardContent>
          </Card>

          {/* Fun Activities & Games */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Gamepad2 className="w-5 h-5 text-success" />
                Fun Activities & Games
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Animal sounds guessing game</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Interactive pet flashcards</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Drag & drop matching</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Spin & speak magic wheel</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Hidden animal reveal game</span>
              </div>
            </CardContent>
          </Card>

          {/* Lesson Information */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-lesson-orange" />
                Lesson Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Duration:</span>
                <span className="font-medium">25–30 minutes</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Slides:</span>
                <span className="font-medium">21 interactive slides</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Class Size:</span>
                <span className="font-medium">One-on-one</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Unit:</span>
                <span className="font-medium">Unit 5: Animals</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Reward:</span>
                <span className="font-medium">🏅 Pet Friend Badge</span>
              </div>
            </CardContent>
          </Card>

          {/* Key Vocabulary */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Book className="w-5 h-5 text-lesson-purple" />
                Key Vocabulary & Sentences
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Pet Animals:</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span>🐱 Cat (meow)</span>
                    <AudioButton text="cat" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>🐶 Dog (woof)</span>
                    <AudioButton text="dog" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>🐟 Fish (bubble)</span>
                    <AudioButton text="fish" />
                  </div>
                </div>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Key Sentences:</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">"It is a cat."</span>
                    <AudioButton text="It is a cat" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">"It is a dog."</span>
                    <AudioButton text="It is a dog" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">"It is a fish."</span>
                    <AudioButton text="It is a fish" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Teaching Notes */}
        <Card className="bg-gradient-card border-0 shadow-card mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="w-5 h-5 text-warning" />
              One-on-One Teaching Notes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm">
              <p>
                <strong>Sound & Action:</strong> Use animal sounds and actions to make pets memorable. Make "meow" sounds for cats, "woof" for dogs, and swimming motions for fish.
              </p>
              <p>
                <strong>Complete Sentences:</strong> Encourage full sentences "It is a cat" rather than just saying "cat." This builds proper sentence structure from the start.
              </p>
              <p>
                <strong>Personal Connection:</strong> Ask students if they have pets at home. Extend the lesson with "I have a cat/dog/fish" if appropriate.
              </p>
              <p>
                <strong>Interactive Elements:</strong> Use the animal sounds game and hidden animal reveals to maintain engagement throughout the lesson.
              </p>
              <p>
                <strong>Homework Suggestion:</strong> Have students draw their pet (real or imaginary) and write "It is a ___" underneath.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            variant="outline" 
            size="lg"
            onClick={() => navigate("/")}
            className="flex items-center gap-2"
          >
            ← Back to Home
          </Button>
          <Button 
            size="lg" 
            onClick={() => navigate("/lesson51")}
            className="flex items-center gap-2 bg-gradient-primary hover:bg-gradient-primary/90"
          >
            <Zap className="w-5 h-5" />
            Meet the Pets!
          </Button>
        </div>
      </div>
    </div>
  );
};