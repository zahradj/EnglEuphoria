import React from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AudioButton } from "@/components/AudioButton";
import { Clock, Users, Target, Star, Book, Volume2, Gamepad2, Zap } from "lucide-react";

export const Lesson42Intro = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-fun p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <Badge variant="secondary" className="mb-4">
            Pre-Starter • Unit 4 • Lesson 2
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">
            🧍 More Body Parts!
          </h1>
          <p className="text-xl text-muted-foreground">
            Learn about mouth, hands, and feet with fun activities
          </p>
        </div>

        {/* Lesson Preview Cards */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-4xl mb-2">👄</div>
              <h3 className="font-bold">Mouth</h3>
              <p className="text-sm text-muted-foreground">This is my mouth</p>
            </CardContent>
          </Card>
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-4xl mb-2">👋</div>
              <h3 className="font-bold">Hands</h3>
              <p className="text-sm text-muted-foreground">These are my hands</p>
            </CardContent>
          </Card>
          <Card className="text-center border-2 border-primary/20 hover:border-primary/40 transition-colors">
            <CardContent className="pt-6">
              <div className="text-4xl mb-2">🦶</div>
              <h3 className="font-bold">Feet</h3>
              <p className="text-sm text-muted-foreground">These are my feet</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {/* What We'll Learn Today */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5 text-primary" />
                What We'll Learn Today
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>New body parts: mouth, hands, feet</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Sentences: "This is my..." / "These are my..."</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Phonics: Letter Hh /h/ (hat, horse, hand)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Review: head, eyes, nose from Lesson 4.1</span>
              </div>
            </CardContent>
          </Card>

          {/* Fun Activities & Games */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Gamepad2 className="w-5 h-5 text-success" />
                Fun Activities & Games
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Simon Says with body parts</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Guess the Body Part game</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Drag & Drop body puzzle</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Speaking practice with gestures</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Interactive spin wheel</span>
              </div>
            </CardContent>
          </Card>

          {/* Lesson Information */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-lesson-orange" />
                Lesson Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Duration:</span>
                <span className="font-medium">25–30 minutes</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Slides:</span>
                <span className="font-medium">22 interactive slides</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Class Size:</span>
                <span className="font-medium">One-on-one</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Language Focus:</span>
                <span className="font-medium">Body parts vocabulary</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Reward:</span>
                <span className="font-medium">🏅 Body Builder Badge</span>
              </div>
            </CardContent>
          </Card>

          {/* Key Vocabulary */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Book className="w-5 h-5 text-lesson-purple" />
                Key Vocabulary & Sentences
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Body Parts:</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span>👄 Mouth</span>
                    <AudioButton text="mouth" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>👋 Hands</span>
                    <AudioButton text="hands" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>🦶 Feet</span>
                    <AudioButton text="feet" />
                  </div>
                </div>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Key Sentences:</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">"This is my mouth."</span>
                    <AudioButton text="This is my mouth" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">"These are my hands."</span>
                    <AudioButton text="These are my hands" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">"These are my feet."</span>
                    <AudioButton text="These are my feet" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Teaching Notes */}
        <Card className="bg-gradient-card border-0 shadow-card mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="w-5 h-5 text-warning" />
              One-on-One Teaching Notes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm">
              <p>
                <strong>Physical Interaction:</strong> Play Simon Says live with the student using their own body parts. Encourage them to touch their mouth, clap their hands, and stomp their feet.
              </p>
              <p>
                <strong>Repetition & Gestures:</strong> Repeat each sentence 3 times with clear gestures. Have the student copy your movements and pronunciation.
              </p>
              <p>
                <strong>Real-Time Practice:</strong> Ask the student to show you their hands, point to their mouth, or wiggle their feet during the lesson.
              </p>
              <p>
                <strong>Homework Suggestion:</strong> Have the student draw a picture of themselves and label mouth, hands, and feet in English.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            variant="outline" 
            size="lg"
            onClick={() => navigate("/")}
            className="flex items-center gap-2"
          >
            ← Back to Home
          </Button>
          <Button 
            size="lg" 
            onClick={() => navigate("/lesson42")}
            className="flex items-center gap-2 bg-gradient-primary hover:bg-gradient-primary/90"
          >
            <Zap className="w-5 h-5" />
            Learn More Body Parts!
          </Button>
        </div>
      </div>
    </div>
  );
};