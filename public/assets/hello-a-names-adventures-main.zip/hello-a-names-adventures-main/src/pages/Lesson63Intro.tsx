import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { FloatingLogo } from "@/components/FloatingLogo";
import { AudioButton } from "@/components/AudioButton";

export default function Lesson63Intro() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-warm relative overflow-hidden">
      <FloatingLogo />
      
      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              👨‍👩‍👧‍👦 Lesson 6.3
            </h1>
            <h2 className="text-2xl md:text-3xl font-semibold text-white/90 mb-2">
              Family Review & Role-Play
            </h2>
            <p className="text-lg text-white/80">
              Review all family members and practice conversations!
            </p>
          </div>

          {/* Lesson Overview */}
          <Card className="p-6 mb-8 bg-white/10 backdrop-blur-sm border-white/20">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center">
              📚 What We'll Review Today
            </h3>
            <div className="grid md:grid-cols-2 gap-4 text-white/90">
              <div>
                <h4 className="font-semibold mb-2">👨‍👩‍👧‍👦 Family Words:</h4>
                <ul className="space-y-1">
                  <li>• Mother & Father</li>
                  <li>• Brother & Sister</li>
                  <li>• Baby & Family</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">🎭 Activities:</h4>
                <ul className="space-y-1">
                  <li>• Family Tree Game</li>
                  <li>• Role-Play Conversations</li>
                  <li>• Phonics: Mm /m/ (mom, milk)</li>
                </ul>
              </div>
            </div>
          </Card>

          {/* Activities Preview */}
          <Card className="p-6 mb-8 bg-white/10 backdrop-blur-sm border-white/20">
            <h3 className="text-xl font-bold text-white mb-4">🎮 Fun Activities</h3>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-3xl mb-2">🌳</div>
                <p className="text-white/90">Family Tree Building</p>
              </div>
              <div className="text-center">
                <div className="text-3xl mb-2">🎭</div>
                <p className="text-white/90">Family Role-Play</p>
              </div>
              <div className="text-center">
                <div className="text-3xl mb-2">🏆</div>
                <p className="text-white/90">Family Champion Quiz</p>
              </div>
            </div>
          </Card>

          {/* Audio Practice */}
          <div className="text-center mb-8">
            <h3 className="text-xl font-bold text-white mb-4">🔊 Family Words Review</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              <AudioButton text="Mother" className="bg-white/20 hover:bg-white/30 text-white" />
              <AudioButton text="Father" className="bg-white/20 hover:bg-white/30 text-white" />
              <AudioButton text="Brother" className="bg-white/20 hover:bg-white/30 text-white" />
              <AudioButton text="Sister" className="bg-white/20 hover:bg-white/30 text-white" />
              <AudioButton text="Baby" className="bg-white/20 hover:bg-white/30 text-white" />
              <AudioButton text="Family" className="bg-white/20 hover:bg-white/30 text-white" />
            </div>
          </div>

          {/* Start Button */}
          <div className="text-center">
            <Button 
              onClick={() => navigate('/lesson/6-3')}
              className="bg-gradient-primary hover:shadow-button transition-all duration-300 text-lg font-semibold px-8 py-4"
            >
              Start Family Review! 👨‍👩‍👧‍👦
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}